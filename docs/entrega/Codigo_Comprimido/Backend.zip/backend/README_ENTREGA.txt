1) python -m venv .venv && activar
2) pip install -r requirements.txt
3) Colocar serviceAccountKey.json aquí
4) Configurar GOOGLE_API_KEY (o en ../.env.local)
5) uvicorn main:app --reload --port 8000
