1) npm install
2) Copiar .env.local.example → .env.local y completar
3) Asegurar backend en :8000
4) npm run dev → http://localhost:3000
Nota: middleware.ts.disabled es intencional (ADR enrutamiento Next 16).
